These folders contain all of the media files used by the projects in the book. 
