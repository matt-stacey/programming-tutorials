// Beginning Java Game Programming, 3rd Edition
// by Jonathan S. Harbour
// DrinkJava program

import java.io.*;

public class DrinkJava {

    public static void main(String args[]) {

        System.out.println("Do you like to drink Java?");
    }
}
