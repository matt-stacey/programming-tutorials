// Beginning Java Game Programming, 3rd Edition
// by Jonathan S. Harbour
// FirstApplet program

import java.awt.*;
import java.applet.*;

public class FirstApplet extends Applet 
{
    public void paint(Graphics g) 
    {
        g.drawString("This is my first Java Applet!", 20, 30);

    }

}
