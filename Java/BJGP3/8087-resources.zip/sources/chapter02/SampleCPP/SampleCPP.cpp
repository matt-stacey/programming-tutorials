// SampleCPP.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <iostream>
using namespace std;

int main(int argc, char argv[])
{
	cout << "I am a C++ program." << endl;
    system("pause");
	return 0;
}

